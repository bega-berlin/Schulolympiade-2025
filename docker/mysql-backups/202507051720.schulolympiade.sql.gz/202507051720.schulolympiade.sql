/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.10-MariaDB, for Linux (x86_64)
--
-- Host: mysql    Database: schulolympiade
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `emoji_mappings`
--

DROP TABLE IF EXISTS `emoji_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emoji_mappings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `emoji` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `trigger_word` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `trigger_word` (`trigger_word`),
  KEY `idx_trigger` (`trigger_word`)
) ENGINE=InnoDB AUTO_INCREMENT=1630 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emoji_mappings`
--

LOCK TABLES `emoji_mappings` WRITE;
/*!40000 ALTER TABLE `emoji_mappings` DISABLE KEYS */;
INSERT INTO `emoji_mappings` VALUES
(1595,'🌀','Ab durch die Röhre','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1596,'🧱','Baumeister','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1597,'🦯','Blinder Hindernislauf','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1598,'🥢','Chopsticks','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1599,'🏰','Das Schloss','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1600,'🥚','Eierlauf','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1601,'🚲','Fahrradrennen','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1602,'🧑‍🧑‍🧒‍🧒','Familienduell','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1603,'🚶','Figuren legen','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1604,'🏗️','Fröbelturm','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1605,'🎯','Geo-Dart','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1606,'🏉','Harzer-Rugby','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1607,'🪡','Knopf annähen','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1608,'🟰','Kopfrechnen','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1609,'🛏️','Laken wenden','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1610,'⚽️','Lattenknaller','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1611,'🎈','Luftballon','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1612,'🍡','Marshmallow Challenge','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1613,'🃏','Memory','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1614,'👀','Menschenkenntnis','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1615,'🧠','Merk\'s dir','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1616,'🧩','Puzzlen','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1617,'❓','Quiz','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1618,'⛷️','Sommerski','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1619,'🎶','Songtitel','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1620,'🗂️','Sortieren','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1621,'🤫','Stille Post','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1622,'🗓️','Wann war das doch gleich?','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1623,'🪣','Wassertransport','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1624,'🕵️‍♂️','Wer ist das?','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1625,'🥓','Wer stiehlt den Speck','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1626,'♟️','Wikingerschach','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1627,'⛵️','Wir fahren über \'n See','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1628,'🤔','Wir schätzen das ONG','2025-06-25 22:27:34','2025-06-25 22:27:34'),
(1629,'🔤','Worttüftelei','2025-06-25 22:27:34','2025-06-25 22:27:34');
/*!40000 ALTER TABLE `emoji_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `results`
--

DROP TABLE IF EXISTS `results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `results` (
  `id` int NOT NULL AUTO_INCREMENT,
  `team` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `disziplin` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `punkte` int NOT NULL,
  `platz` int NOT NULL,
  `uhr` time NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_team` (`team`),
  KEY `idx_disziplin` (`disziplin`),
  KEY `idx_uhr` (`uhr`)
) ENGINE=InnoDB AUTO_INCREMENT=5442 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `results`
--

LOCK TABLES `results` WRITE;
/*!40000 ALTER TABLE `results` DISABLE KEYS */;
INSERT INTO `results` VALUES
(5441,'Klasse 5.2','Wer ist das?',10,1,'15:54:41','2025-07-05 13:54:41','2025-07-05 13:54:41');
/*!40000 ALTER TABLE `results` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-05 17:20:01
